public interface Koleksi {
    public void tampilkanData();
}