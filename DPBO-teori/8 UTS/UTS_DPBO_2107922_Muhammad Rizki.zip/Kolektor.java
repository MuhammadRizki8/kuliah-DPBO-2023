public interface Kolektor {
    public String getNIK();
    public String getNama();
    public String getAlamat();
    public int getTahunAktif();
    public String getKodeClub();
    }