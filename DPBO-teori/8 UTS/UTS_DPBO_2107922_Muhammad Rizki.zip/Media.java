public interface Media {
    String getKode();
    String getJudul();
    String getDeskripsi();
}