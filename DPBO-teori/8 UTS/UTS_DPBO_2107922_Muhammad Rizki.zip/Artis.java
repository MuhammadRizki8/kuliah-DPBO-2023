public interface Artis {
    String getNIK();
    void setNIK(String NIK);
    String getNama();
    void setNama(String nama);
    String getAlamat();
    void setAlamat(String alamat);
    int getTahunAktif();
    void setTahunAktif(int tahunAktif);
    String getKodeClub();
    void setKodeClub(String kodeClub);
}