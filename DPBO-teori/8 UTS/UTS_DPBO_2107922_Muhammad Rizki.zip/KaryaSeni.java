public interface KaryaSeni {
    String getKode();
    String getJudul();
    String getDeskripsi();
}