public interface Club {
    String getKodeClub();
    int getTahunBerdiri();
    String getNamaClub();
    String getAlamat();
}